package com.oabulk

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import org.json.JSONTokener
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val BG = Color.parseColor("#0f172a")
    private val CARD = Color.parseColor("#1e293b")
    private val BORDER = Color.parseColor("#334155")
    private val TEXT = Color.parseColor("#e2e8f0")
    private val MUTED = Color.parseColor("#94a3b8")
    private val OK = Color.parseColor("#86efac")
    private val ERR = Color.parseColor("#fca5a5")
    private val desktopUa = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private lateinit var web: WebView
    private lateinit var panel: ScrollView
    private lateinit var etLinks: EditText
    private lateinit var etDelay: EditText
    private lateinit var etFailed: EditText
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnDownload: Button
    private lateinit var btnClear: Button
    private lateinit var tvLog: TextView
    private lateinit var logScroll: ScrollView
    private lateinit var tvCount: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvFailedCount: TextView
    private lateinit var tvEmpty: TextView
    private lateinit var table: TableLayout

    private val results = ArrayList<Map<String, String>>()
    private var failedLinks: List<String> = emptyList()
    private val logBuf = SpannableStringBuilder()
    private var running = false
    private var shouldStop = false
    private var loginNeeded = false
    private var loadSignal: CompletableDeferred<Unit>? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val prefs by lazy { getSharedPreferences("oa", MODE_PRIVATE) }
    private val resFile by lazy { File(filesDir, "results.jsonl") }

    // ---------- helpers ----------
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        if (stroke != null) g.setStroke(dp(1), stroke)
        return g
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = shape(CARD, 12, BORDER)
        c.setPadding(dp(14), dp(14), dp(14), dp(14))
        val lp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        c.layoutParams = lp
        return c
    }

    private fun tv(t: String, size: Float = 13f, color: Int = TEXT, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    private fun label(t: String): TextView {
        val v = tv(t.uppercase(), 11f, MUTED, true)
        v.setPadding(0, dp(4), 0, dp(5))
        return v
    }

    private fun edit(hintText: String, lines: Int = 1, mono: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hintText
        e.setHintTextColor(Color.parseColor("#64748b"))
        e.setTextColor(Color.parseColor("#f1f5f9"))
        e.minLines = lines
        e.textSize = 12f
        e.gravity = Gravity.TOP or Gravity.START
        if (mono) e.typeface = Typeface.MONOSPACE
        e.background = shape(BG, 8, BORDER)
        e.setPadding(dp(10), dp(8), dp(10), dp(8))
        e.layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        return e
    }

    private fun btn(t: String, bg: Int, fg: Int): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.textSize = 12f
        b.setTypeface(b.typeface, Typeface.BOLD)
        b.setTextColor(fg)
        b.background = shape(bg, 8)
        val lp = LinearLayout.LayoutParams(0, dp(46), 1f)
        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        b.layoutParams = lp
        return b
    }

    private fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        v.forEach { r.addView(it) }
        return r
    }

    private fun setEnabledUi(b: Button, on: Boolean) {
        b.isEnabled = on
        b.alpha = if (on) 1f else 0.45f
    }

    private fun cell(t: String, header: Boolean): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 11f
        v.maxLines = 1
        v.ellipsize = TextUtils.TruncateAt.END
        v.maxWidth = dp(170)
        v.setPadding(dp(8), dp(7), dp(8), dp(7))
        v.setTextColor(if (header) MUTED else TEXT)
        if (header) {
            v.setTypeface(v.typeface, Typeface.BOLD)
            v.setBackgroundColor(BG)
        }
        return v
    }

    // ---------- logging ----------
    private fun log(text: String, type: String = "") {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val line = "[" + time + "] " + text + "\n"
        val start = logBuf.length
        logBuf.append(line)
        val color = when (type) { "ok" -> OK; "err" -> ERR; else -> MUTED }
        logBuf.setSpan(ForegroundColorSpan(color), start, logBuf.length, 0)
        if (logBuf.length > 8000) logBuf.delete(0, logBuf.length - 6000)
        tvLog.text = logBuf
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ---------- table ----------
    private fun addRow(index: Int, row: Map<String, String>) {
        val tr = TableRow(this)
        tr.addView(cell(index.toString(), false))
        COLUMNS.forEach { tr.addView(cell(row[it] ?: "", false)) }
        table.addView(tr)
        if (table.childCount > 201) table.removeViewAt(1)
        tvEmpty.visibility = View.GONE
    }

    private fun updateCounts() {
        tvCount.text = results.size.toString()
        setEnabledUi(btnDownload, results.isNotEmpty() || failedLinks.isNotEmpty())
    }

    private fun renderFailed() {
        tvFailedCount.text = failedLinks.size.toString()
        etFailed.setText(failedLinks.joinToString("\n"))
        prefs.edit().putString("failed", failedLinks.joinToString("\n")).apply()
        updateCounts()
    }

    private fun persist(row: Map<String, String>) {
        try { resFile.appendText(JSONObject(row).toString() + "\n") } catch (e: Exception) { }
    }

    private fun restore() {
        try {
            if (!resFile.exists()) return
            resFile.readLines().forEach { ln ->
                try {
                    val o = JSONObject(ln)
                    val m = LinkedHashMap<String, String>()
                    o.keys().forEach { k -> m[k] = o.optString(k, "") }
                    results.add(m)
                    addRow(results.size, m)
                } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
    }

    // ---------- UI ----------
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = BG
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        // Browser layer (always attached, so scraping keeps working)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = true
        web.settings.builtInZoomControls = true
        web.settings.displayZoomControls = false
        web.settings.userAgentString = desktopUa
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, url: String?) { loadSignal?.complete(Unit) }
        }

        val bBackPanel = btn("\u2190 Panel", Color.parseColor("#4f46e5"), Color.WHITE)
        val bScrapePage = btn("\u2B07 Scrape page", Color.parseColor("#065f46"), Color.parseColor("#a7f3d0"))
        val bReload = btn("\uD83D\uDD04", BORDER, Color.parseColor("#cbd5e1"))
        val bHome = btn("\uD83C\uDFE0", BORDER, Color.parseColor("#cbd5e1"))
        val browserBar = row(bBackPanel, bScrapePage, bReload, bHome)
        browserBar.setBackgroundColor(BG)
        val browserLayer = LinearLayout(this)
        browserLayer.orientation = LinearLayout.VERTICAL
        browserLayer.addView(browserBar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        browserLayer.addView(web, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // Panel
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(24), dp(16), dp(28))
        col.addView(tv("OfficeAlly Bulk Scraper", 22f, Color.parseColor("#38bdf8"), true))
        val sub = tv("Results app ke andar \u2022 Download jab chaho \u2022 Smart wait", 12f, MUTED)
        sub.setPadding(0, dp(2), 0, dp(14))
        col.addView(sub)

        val linksCard = card()
        linksCard.addView(label("Paste Links (one per line)"))
        etLinks = edit("https://sc.officeally.com/verify-eligibility/transaction/...", 5, true)
        etLinks.setText(prefs.getString("links", ""))
        linksCard.addView(etLinks)
        linksCard.addView(label("Extra Delay (sec) \u2014 optional"))
        etDelay = edit("0")
        etDelay.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        etDelay.setText(prefs.getString("delay", "0"))
        linksCard.addView(etDelay)

        btnStart = btn("\u25B6 Start Scrape", Color.parseColor("#2563eb"), Color.WHITE)
        btnStop = btn("\u23F9 Stop", Color.parseColor("#7f1d1d"), Color.parseColor("#fecaca"))
        btnDownload = btn("\u2B07 Download All CSV", Color.parseColor("#065f46"), Color.parseColor("#a7f3d0"))
        btnClear = btn("Clear Results", BORDER, Color.parseColor("#cbd5e1"))
        val btnBrowser = btn("\uD83C\uDF10 Browser / Login", Color.parseColor("#4f46e5"), Color.WHITE)
        val btnPageScrape = btn("\uD83D\uDCC4 Scrape this page", BORDER, Color.parseColor("#cbd5e1"))
        val btnBattery = btn("\uD83D\uDD0B Battery allow (background)", BORDER, Color.parseColor("#cbd5e1"))
        linksCard.addView(row(btnStart, btnStop))
        linksCard.addView(row(btnDownload, btnClear))
        linksCard.addView(row(btnBrowser, btnPageScrape))
        linksCard.addView(row(btnBattery))
        val hint = tv("\u2022 Pehle Browser/Login mein Office Ally par login karein\n\u2022 Page load ka wait (max ~3 min per link), 60s/120s par auto reload\n\u2022 Fail links end mein auto retry (2 rounds)\n\u2022 App background mein bhi chalti hai", 11f, Color.parseColor("#64748b"))
        hint.setPadding(0, dp(8), 0, 0)
        linksCard.addView(hint)
        col.addView(linksCard)

        val logCard = card()
        tvLog = tv("", 11f, MUTED)
        tvLog.typeface = Typeface.MONOSPACE
        logScroll = ScrollView(this)
        logScroll.background = shape(BG, 8, BORDER)
        logScroll.setPadding(dp(8), dp(6), dp(8), dp(6))
        logScroll.addView(tvLog)
        logCard.addView(label("Log"))
        logCard.addView(logScroll, LinearLayout.LayoutParams(MATCH_PARENT, dp(160)))
        col.addView(logCard)

        val failCard = card()
        tvFailedCount = tv("0", 13f, TEXT, true)
        failCard.addView(row(tv("Non-downloaded links: ", 13f, MUTED), tvFailedCount))
        etFailed = edit("Jo links download nahi hue wo yahan aa jayenge", 3, true)
        etFailed.keyListener = null
        failCard.addView(etFailed)
        col.addView(failCard)

        val resCard = card()
        tvCount = tv("0", 13f, TEXT, true)
        tvStatus = tv("Idle", 13f, TEXT, true)
        resCard.addView(row(tv("Scraped: ", 13f, MUTED), tvCount, tv("      Status: ", 13f, MUTED), tvStatus))
        table = TableLayout(this)
        val headerRow = TableRow(this)
        headerRow.addView(cell("#", true))
        COLUMNS.forEach { headerRow.addView(cell(it, true)) }
        table.addView(headerRow)
        val hs = HorizontalScrollView(this)
        hs.background = shape(BG, 8, BORDER)
        hs.addView(table)
        val tlp = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        tlp.setMargins(0, dp(8), 0, 0)
        resCard.addView(hs, tlp)
        tvEmpty = tv("No data yet \u2014 links paste karke Start dabao", 12f, Color.parseColor("#64748b"))
        tvEmpty.gravity = Gravity.CENTER
        tvEmpty.setPadding(0, dp(18), 0, dp(6))
        resCard.addView(tvEmpty, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        col.addView(resCard)

        panel = ScrollView(this)
        panel.setBackgroundColor(BG)
        panel.isFillViewport = true
        panel.addView(col)

        val frame = FrameLayout(this)
        frame.setBackgroundColor(BG)
        frame.addView(browserLayer, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        frame.addView(panel, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(frame)

        // actions
        btnStart.setOnClickListener { onStart() }
        btnStop.setOnClickListener { onStop() }
        btnDownload.setOnClickListener { downloadCsv() }
        btnClear.setOnClickListener {
            if (running) { Toast.makeText(this, "Pehle Stop karein", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            results.clear()
            failedLinks = emptyList()
            try { resFile.delete() } catch (e: Exception) { }
            table.removeViews(1, table.childCount - 1)
            tvEmpty.visibility = View.VISIBLE
            renderFailed()
            updateCounts()
            log("Results cleared")
        }
        btnBrowser.setOnClickListener { panel.visibility = View.GONE }
        bBackPanel.setOnClickListener { CookieManager.getInstance().flush(); panel.visibility = View.VISIBLE }
        bReload.setOnClickListener { web.reload() }
        bHome.setOnClickListener { web.loadUrl(HOME) }
        btnPageScrape.setOnClickListener { scrapeThisPage() }
        bScrapePage.setOnClickListener { scrapeThisPage() }
        btnBattery.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }

        failedLinks = (prefs.getString("failed", "") ?: "").split("\n").filter { it.startsWith("http") }
        setEnabledUi(btnStop, false)
        restore()
        renderFailed()
        updateCounts()
        web.loadUrl(HOME)
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putString("links", etLinks.text.toString()).putString("delay", etDelay.text.toString()).apply()
        CookieManager.getInstance().flush()
        if (running) web.resumeTimers()
    }

    override fun onStop() {
        super.onStop()
        if (running) web.resumeTimers()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (panel.visibility != View.VISIBLE) {
            panel.visibility = View.VISIBLE
        } else {
            moveTaskToBack(true)
        }
    }

    // ---------- JS / page helpers ----------
    private suspend fun evalJs(script: String, timeout: Long = 15000): String? {
        val d = CompletableDeferred<String?>()
        web.evaluateJavascript(script) { v -> d.complete(v) }
        val raw = withTimeoutOrNull(timeout) { d.await() } ?: return null
        return try {
            val o = JSONTokener(raw).nextValue()
            if (o is String) o else null
        } catch (e: Exception) { null }
    }

    private suspend fun scrape(): Map<String, String>? {
        val s = evalJs(SCRAPE_JS) ?: return null
        return try {
            val o = JSONObject(s)
            val m = LinkedHashMap<String, String>()
            o.keys().forEach { k -> m[k] = o.optString(k, "") }
            m
        } catch (e: Exception) { null }
    }

    private fun isGood(d: Map<String, String>?): Boolean {
        return d != null && !d["Member Name"].isNullOrEmpty() && !d["Member ID"].isNullOrEmpty()
    }

    private suspend fun waitForLoad() {
        withTimeoutOrNull(15000) { loadSignal!!.await() }
        delay(1500)
    }

    private suspend fun loadUrl(url: String) {
        loadSignal = CompletableDeferred()
        web.loadUrl(url)
        waitForLoad()
    }

    private suspend fun reloadPage() {
        loadSignal = CompletableDeferred()
        web.reload()
        waitForLoad()
    }

    private fun scrapeThisPage() {
        lifecycleScope.launch {
            val d = scrape()
            if (d == null || !d.values.any { it.isNotEmpty() }) {
                Toast.makeText(this@MainActivity, "Koi data nahi mila!", Toast.LENGTH_LONG).show()
                return@launch
            }
            results.add(d)
            persist(d)
            addRow(results.size, d)
            updateCounts()
            log("Page scrape ho gaya: " + (d["Member Name"] ?: ""), "ok")
            Toast.makeText(this@MainActivity, "Results mein add ho gaya (Panel mein dekhein)", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- bulk run ----------
    private suspend fun processOne(url: String, delayMs: Long): Map<String, String>? {
        loadUrl(url)
        val u = (web.url ?: "").lowercase()
        if (u.contains("login") || u.contains("signin") || u.contains("logon")) {
            loginNeeded = true
            return null
        }
        val start = System.currentTimeMillis()
        var coreSince = 0L
        var reloaded = 0
        while (System.currentTimeMillis() - start < MAX_WAIT_MS) {
            if (shouldStop) return null
            val d = scrape()
            if (isGood(d)) {
                if (!d!!["Payer"].isNullOrEmpty()) {
                    if (delayMs > 0) delay(delayMs)
                    return d
                }
                if (coreSince == 0L) coreSince = System.currentTimeMillis()
                if (System.currentTimeMillis() - coreSince > 6000) return d
            }
            val elapsed = System.currentTimeMillis() - start
            if (elapsed > 60000L * (reloaded + 1) && reloaded < 2) {
                reloaded++
                reloadPage()
                coreSince = 0L
            }
            delay(1000)
        }
        return null
    }

    private suspend fun runPass(urls: List<String>, delayMs: Long, labelText: String): List<String> {
        val failed = ArrayList<String>()
        val total = urls.size
        for (i in 0 until total) {
            if (shouldStop) break
            val url = urls[i]
            log(labelText + " Opening " + (i + 1) + "/" + total + "...")
            var data: Map<String, String>? = null
            try { data = processOne(url, delayMs) } catch (e: Exception) { data = null }
            if (shouldStop) break
            if (loginNeeded) {
                log("Login page aaya. Browser mein login karein, phir dobara Start dabayein.", "err")
                shouldStop = true
                break
            }
            if (isGood(data)) {
                results.add(data!!)
                persist(data)
                addRow(results.size, data)
                updateCounts()
                log("\u2713 " + labelText + " " + (i + 1) + "/" + total + " \u2014 " + (data["Member Name"] ?: ""), "ok")
            } else {
                failed.add(url)
                log("\u2717 " + labelText + " " + (i + 1) + "/" + total + " \u2014 download nahi hua \u2192 next (end me retry hoga)", "err")
            }
        }
        return failed
    }

    private fun onStop() {
        if (!running) return
        shouldStop = true
        loadSignal?.complete(Unit)
        tvStatus.text = "Stopping..."
        log("Stop requested", "err")
    }

    private fun onStart() {
        if (running) return
        val urls = etLinks.text.toString().trim().split("\n").map { it.trim() }.filter { it.startsWith("http") }
        if (urls.isEmpty()) {
            log("Links paste karo", "err")
            Toast.makeText(this, "Links paste karo", Toast.LENGTH_SHORT).show()
            return
        }
        val delayMs = Math.max(0.0, (etDelay.text.toString().toDoubleOrNull() ?: 0.0) * 1000).toLong()
        running = true
        shouldStop = false
        loginNeeded = false
        setEnabledUi(btnStart, false)
        setEnabledUi(btnStop, true)
        tvStatus.text = "Running..."
        logBuf.clear()
        tvLog.text = ""
        failedLinks = emptyList()
        renderFailed()
        log("Starting " + urls.size + " links | Extra delay " + (delayMs / 1000.0) + "s | Smart wait ON")
        prefs.edit().putString("links", etLinks.text.toString()).putString("delay", etDelay.text.toString()).apply()

        ContextCompat.startForegroundService(this, Intent(this, KeepAliveService::class.java))
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "oabulk:run")
            wakeLock?.acquire(6 * 60 * 60 * 1000L)
        } catch (e: Exception) { }

        lifecycleScope.launch {
            try {
                var failed = runPass(urls, delayMs, "[Pass 1]")
                var round = 2
                while (round <= 3 && failed.isNotEmpty() && !shouldStop) {
                    log("Retry round " + (round - 1) + ": " + failed.size + " failed links dobara...")
                    failed = runPass(failed, delayMs, "[Retry " + (round - 1) + "]")
                    round++
                }
                failedLinks = failed
                renderFailed()
                log("All done \u2713  Total: " + results.size, "ok")
                tvStatus.text = "Done"
            } catch (e: Exception) {
                log("Error: " + e.message, "err")
                tvStatus.text = "Error"
            } finally {
                running = false
                shouldStop = false
                setEnabledUi(btnStart, true)
                setEnabledUi(btnStop, false)
                stopService(Intent(this@MainActivity, KeepAliveService::class.java))
                try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (e: Exception) { }
            }
        }
    }

    // ---------- CSV ----------
    private fun q(v: String?): String = "\"" + (v ?: "").replace("\"", "\"\"") + "\""

    private fun downloadCsv() {
        if (results.isEmpty() && failedLinks.isEmpty()) return
        val sb = StringBuilder("\uFEFF")
        val headers = COLUMNS + "Non Downloaded Links"
        sb.append(headers.joinToString(",") { q(it) }).append("\n")
        val n = maxOf(results.size, failedLinks.size)
        for (i in 0 until n) {
            val rowMap = results.getOrNull(i)
            val vals = COLUMNS.map { q(rowMap?.get(it)) }.toMutableList()
            vals.add(q(failedLinks.getOrNull(i)))
            sb.append(vals.joinToString(",")).append("\n")
        }
        val name = "OfficeAlly_Bulk_" + results.size + "_" + System.currentTimeMillis() + ".csv"
        saveCsv(name, sb.toString())
    }

    private fun saveCsv(name: String, text: String) {
        try {
            val bytes = text.toByteArray(Charsets.UTF_8)
            var uri: Uri? = null
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues()
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                if (uri != null) contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            } else {
                val f = File(getExternalFilesDir(null), name)
                f.writeBytes(bytes)
                Toast.makeText(this, "Saved: " + f.absolutePath, Toast.LENGTH_LONG).show()
            }
            log("Downloaded " + results.size + " rows + " + failedLinks.size + " failed links", "ok")
            if (uri != null) {
                val saved = uri
                AlertDialog.Builder(this)
                    .setTitle("CSV save ho gayi")
                    .setMessage("Downloads folder mein:\n" + name)
                    .setPositiveButton("Share") { _, _ ->
                        val i = Intent(Intent.ACTION_SEND)
                        i.type = "text/csv"
                        i.putExtra(Intent.EXTRA_STREAM, saved)
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivity(Intent.createChooser(i, "CSV share karein"))
                    }
                    .setNegativeButton("OK", null)
                    .show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "CSV save nahi hui: " + e.message, Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        const val HOME = "https://sc.officeally.com"
        const val MAX_WAIT_MS = 180000L
        val COLUMNS = listOf(
            "Transaction ID", "Member Name", "Member ID", "Date of Birth", "Gender", "Address",
            "Group Number", "Plan Begin Date", "Plan Name", "Payer", "Coverage Status", "Identifier Code"
        )

        const val SCRAPE_JS = """
(function(){
  const data = {
    'Transaction ID': '', 'Member Name': '', 'Member ID': '', 'Date of Birth': '', 'Gender': '', 'Address': '',
    'Group Number': '', 'Plan Begin Date': '', 'Plan Name': '', 'Payer': '', 'Coverage Status': '', 'Identifier Code': ''
  };
  const body0 = document.body ? (document.body.innerText || '') : '';
  const titleEl = document.querySelector('.summary__value');
  if (titleEl) {
    const t = (titleEl.innerText || '').trim();
    if (/Transaction ID/i.test(t)) data['Transaction ID'] = t.replace(/Transaction ID:?/i, '').trim();
  }
  if (!data['Transaction ID']) {
    const m = body0.match(/Transaction ID[:\s]*([A-Z0-9\-]+)/i);
    if (m) data['Transaction ID'] = m[1].trim();
  }
  document.querySelectorAll('.summary__group').forEach(group => {
    const label = ((group.querySelector('.summary__label') || {}).innerText || '').trim();
    const value = ((group.querySelector('.summary__value') || {}).innerText || '').trim().replace(/\n+/g, ' ');
    if (!label || !value) return;
    const l = label.toLowerCase();
    if (l.includes('member name') || l === 'name') data['Member Name'] = value;
    else if (l.includes('member id') || l.includes('subscriber id') || l === 'id') data['Member ID'] = value;
    else if (l.includes('date of birth') || l.includes('dob') || l.includes('birth')) data['Date of Birth'] = value;
    else if (l.includes('gender') || l.includes('sex')) data['Gender'] = value;
    else if (l.includes('address')) data['Address'] = value;
    else if (l.includes('group number') || l.includes('group #') || l.includes('group id')) data['Group Number'] = value;
    else if (l.includes('plan begin') || l.includes('effective') || l.includes('start date')) data['Plan Begin Date'] = value;
    else if (l.includes('plan name') || l.includes('plan type')) data['Plan Name'] = value;
    else if (l.includes('identifier code') || l.includes('identifier')) data['Identifier Code'] = value;
    else if (l.includes('transaction')) data['Transaction ID'] = data['Transaction ID'] || value;
    else data[label] = value;
  });
  const body = body0;
  if (!data['Member Name']) { const m = body.match(/Member Name[:\s]*([^\n]+)/i); if (m) data['Member Name'] = m[1].trim(); }
  if (!data['Member ID']) { const m = body.match(/(?:Member ID|Subscriber ID)[:\s]*([A-Z0-9\-]+)/i); if (m) data['Member ID'] = m[1].trim(); }
  if (!data['Date of Birth']) { const m = body.match(/(?:Date of Birth|DOB)[:\s]*([0-9\/\-]+)/i); if (m) data['Date of Birth'] = m[1].trim(); }
  if (!data['Gender']) { const m = body.match(/Gender[:\s]*(Male|Female|M|F|Other)/i); if (m) data['Gender'] = m[1].trim(); }
  if (!data['Address']) { const m = body.match(/Address[:\s]*([^\n]+)/i); if (m) data['Address'] = m[1].trim(); }
  if (!data['Group Number']) { const m = body.match(/Group (?:Number|#|ID)[:\s]*([A-Z0-9\-]+)/i); if (m) data['Group Number'] = m[1].trim(); }
  if (!data['Plan Begin Date']) { const m = body.match(/(?:Plan Begin Date|Effective Date|Start Date)[:\s]*([0-9\/\-]+)/i); if (m) data['Plan Begin Date'] = m[1].trim(); }
  if (!data['Plan Name']) { const m = body.match(/Plan Name[:\s]*([^\n]+)/i); if (m) data['Plan Name'] = m[1].trim(); }
  const payerBtn = document.querySelector('button.btn.payer, button.payer, .btn.payer');
  if (payerBtn) {
    const nameEl = payerBtn.querySelector('.fs-18, .fw-500, p:not(.payer__label)');
    if (nameEl) data['Payer'] = nameEl.innerText.trim();
    else {
      const all = payerBtn.innerText.replace(/Payer/i, '').replace(/Active Coverage|Inactive/i, '').trim();
      if (all) data['Payer'] = all;
    }
    const statusEl = payerBtn.querySelector('.payer__status, .payer__coverage');
    if (statusEl) data['Coverage Status'] = statusEl.innerText.trim();
  }
  if (!data['Coverage Status'] && /Active Coverage/i.test(body)) data['Coverage Status'] = 'Active Coverage';
  if (!data['Payer']) {
    const m = body.match(/Payer[:\s]*([^\n]+)/i);
    if (m) data['Payer'] = m[1].replace(/Active Coverage|Inactive/i, '').trim();
  }
  if (!data['Identifier Code']) {
    const idTitle = Array.from(document.querySelectorAll('.subgroup__title, .subgroup__pill, span, div, p, label'))
      .find(el => /Identifier Code/i.test(el.innerText || '') && (el.innerText || '').trim().length < 40);
    if (idTitle) {
      const group = idTitle.closest('.subgroup, .summary__group, [class*="subgroup"], [class*="group"]') || idTitle.parentElement;
      if (group) {
        const candidates = group.querySelectorAll('.subgroup__value, .summary__value, .fs-14, .fs-16, .fw-500, span, p, div');
        for (const c of candidates) {
          const txt = (c.innerText || '').trim();
          if (txt && !/Identifier Code/i.test(txt) && txt.length > 1 && txt.length < 50) { data['Identifier Code'] = txt; break; }
        }
        if (!data['Identifier Code'] && idTitle.nextElementSibling) {
          const next = (idTitle.nextElementSibling.innerText || '').trim();
          if (next && !/Identifier Code/i.test(next)) data['Identifier Code'] = next;
        }
      }
    }
    if (!data['Identifier Code']) {
      const m = body.match(/Identifier Code[:\s]*([A-Z0-9\-]+)/i);
      if (m) data['Identifier Code'] = m[1].trim();
    }
  }
  return JSON.stringify(data);
})();
"""
    }
}
